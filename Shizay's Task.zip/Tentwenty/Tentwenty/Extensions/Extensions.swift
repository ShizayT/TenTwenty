
//
//  Constants.swift
//  Tentwenty
//
//  Created by Shizay on 07/08/2022.
//

import Foundation
import UIKit

extension UICollectionViewCell {
    //MARK:- Identifiers
    static var identifier: String {
        return String(describing: self)
    }
    
    //MARK:- NIB
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
}

import NVActivityIndicatorView
extension UIViewController : NVActivityIndicatorViewable {
    
    func showLoader() -> Void {
        self.startAnimating()
    }
    
    func hideLoader() -> Void {
        self.stopAnimating()
    }
    
}
