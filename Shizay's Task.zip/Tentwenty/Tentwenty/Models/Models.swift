//
//  Constants.swift
//  Tentwenty
//
//  Created by Shizay on 07/08/2022.
//

import Foundation

struct MoviesModel: Decodable {
    
}
