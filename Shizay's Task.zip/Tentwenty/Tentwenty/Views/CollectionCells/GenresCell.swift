//
//  Constants.swift
//  Tentwenty
//
//  Created by Shizay on 07/08/2022.
//

import UIKit

class GenresCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
