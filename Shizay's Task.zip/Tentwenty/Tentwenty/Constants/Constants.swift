//
//  Constants.swift
//  Tentwenty
//
//  Created by Shizay on 07/08/2022.
//

import Foundation
import UIKit

class Constants {
    
    /// APP BASE STRINGS
    static let APP_BASE_URL = "https://api.themoviedb.org/3/"
    
    /// API END POINTS
    static let getMovies = "movie/upcoming"
}
