
//
//  Constants.swift
//  Tentwenty
//
//  Created by Shizay on 07/08/2022.
//

import UIKit

class MovieDetailsVC: UIViewController {
    
    @IBOutlet weak var cvGenres: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configCollectionViews()
    }
    
    func configCollectionViews(){
        cvGenres.delegate = self
        cvGenres.dataSource = self
        cvGenres.register(UINib(nibName: "GenresCell", bundle: nil), forCellWithReuseIdentifier: "GenresCell")
        
    }
    
}

//MARK: - Collection view delegate methods
extension MovieDetailsVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 5
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GenresCell", for: indexPath) as! GenresCell
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let cellsPerline = 3
        let width = CGFloat((Int(cvGenres.frame.width)/cellsPerline)-(4*cellsPerline))
        let height = cvGenres.frame.height
        return CGSize(width: width, height: height)
        
    }
}
