
//
//  Constants.swift
//  Tentwenty
//
//  Created by Shizay on 07/08/2022.
//

import UIKit

class WatchVC: UIViewController {
    
    //MARK: - @IBOutlets
    @IBOutlet weak var tableView: UITableView!
    
    var moviesList = [String]()
    var tableData = [MoviesData(imageName: "movie1", title: "Free Guy"),
                     MoviesData(imageName: "movie2", title: "The King's Man"),
                     MoviesData(imageName: "movie3", title: "Jojo Rabbit")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setTableView()
        setNavRightBarItems()
        self.navigationItem.title = "Watch"
    }
    func setTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(WatchCell.nib, forCellReuseIdentifier: WatchCell.identifier)
    }
    
    func setNavRightBarItems() {
        
        let notifyButton = UIBarButtonItem(image: UIImage(named: "search"), style: .done, target: self, action: #selector(searchTapped))
        self.navigationItem.rightBarButtonItem = notifyButton
        
    }
    
    @objc func searchTapped() {
        
        let nextVC = SearchVC(nibName: "SearchVC", bundle: nil)
        nextVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(nextVC, animated: true)
        
    }
    
    
}

//MARK: - Extension UITableView Methods
extension WatchVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: WatchCell.identifier, for: indexPath) as! WatchCell
        cell.cellData = tableData[indexPath.row]
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nextVC = MovieDetailsVC(nibName: "MovieDetailsVC", bundle: nil)
        nextVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}

// MARK: - API CALLINGS
extension WatchVC {
    
    func getMovies() {
        
        self.startAnimating()
        RequestServices.shared.getData(endUrl: Constants.getMovies) { data, error in
            self.stopAnimating()
            
            guard error == nil else {
                self.moviesList.removeAll()
                self.tableView.reloadData()
                print(error!.localizedDescription)
                return
            }
            
            if let data : Data = data as? Data {
                
                let decoder = JSONDecoder()
                
                do {
                    
                    // i could'nt get response due to api that's why i can't decode model here.
                    let movie = try decoder.decode(MoviesModel.self, from: data)
                    self.moviesList.removeAll()
                    self.tableView.reloadData()
                    
                } catch {
                    
                    self.moviesList.removeAll()
                    self.tableView.reloadData()
                    print(error.localizedDescription)
                    
                }
            }
        }
    }
}

struct MoviesData{
    var imageName       : String
    var title           : String
}
