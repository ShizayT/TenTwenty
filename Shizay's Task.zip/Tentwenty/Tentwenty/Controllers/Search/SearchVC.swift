
//
//  Constants.swift
//  Tentwenty
//
//  Created by Shizay on 07/08/2022.
//

import UIKit

class SearchVC: UIViewController {
    
    //MARK: - @IBOutlets
    @IBOutlet weak var tableView: UITableView!
    
    var tableData = [SearchData(imageName: "movie1", title: "Timless", description: "Fantasy"),
                     SearchData(imageName: "movie2", title: "In time", description: "Sci-Fi"),
                     SearchData(imageName: "movie3", title: "A time to kill", description: "Crime")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setTableView()
    }
    func setTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(SearchCell.nib, forCellReuseIdentifier: SearchCell.identifier)
    }
    
}

//MARK: - Extension UITableView Methods
extension SearchVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: SearchCell.identifier, for: indexPath) as! SearchCell
        cell.cellData = tableData[indexPath.row]
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}
struct SearchData{
    var imageName       : String
    var title           : String
    var description     : String
}
